import React, { useState, useEffect } from 'react'
import axios from 'axios';
import { connect } from "react-redux";
import $ from 'jquery';

import './GroupCreate.css';
import "react-datepicker/dist/react-datepicker.css";

window.$ = $;


const GroupCreate = (props) => {
    
    const [branch, setBranch] = useState([]);
    const [getbranch, setGetBranch] = useState("");
    const [groupname, setgroupname] = useState("");
    const [startDate, setStartDate] = useState("");
    
    const [endDate, setEndDate] = useState();
    const [testTime, setTestTime] = useState("");
    const [department, setDepartment] = useState([]);
    const [getdepartment, setGetDepartment] = useState("");
    const [position, setPosition] = useState([]);
    const [getposition, setGetPosition] = useState("");

    const [checkbox, setCheckbox] = useState([]);

    useEffect(() => {
        async function getCategory() {
            try {
                const response = await axios({
                    url: "http://localhost:8000/users/getAttributes", method: "GET", headers: {
                        'Content-Type': "application/json",
                        'Authorization': `Bearer ${localStorage.getItem("token")}`
                    }
                });
                const body = await response.data;
                console.log(body);
                // setItems(body.map(({ positions }) => ({ label: positions, value:positions  })));
                setPosition(body.positions);
                setDepartment(body.departments);
                setBranch(body.branches);
            }
            catch (error) {
                console.log(error);
            }
        }
        if(getdepartment <= 0 && getposition <= 0 && getbranch <=0){
            getCategory();
        }

        async function getCheckbox() {
            try {
                const response = await axios({
                    url: "http://localhost:8000/questions/categories", method: "GET", headers: {
                        'Content-Type': "application/json",
                        'Authorization': `Bearer ${localStorage.getItem("token")}`
                    }
                });
                const body = await response.data.categories;
                setCheckbox(body);
            }
            catch (error) {
                console.log(error)
            }
        }
        if(checkbox.length <= 0){
            getCheckbox();
        }
    }, []);

    const [checkedItems, setCheckedItems] = useState([]);

    const handleChange = event => {

        var checkboxes = document.querySelectorAll("input[type=checkbox]");

        var checked = [];

        for (var i = 0; i < checkboxes.length; i++) {
            var checkbox = checkboxes[i];
            if (checkbox.checked) checked.push(checkbox.value);
        }

        setCheckedItems({
            ...checkedItems,
            checked
        });

        console.log(checkedItems);
    };
    const starthandle=event=>{
        $('[name="date_start"]').on('change',function() {
            var dataEnd = $(this).val();
            setStartDate(((new Date(dataEnd)).getTime())/1000)
            
          })
    }
    const endhandle=event=>{
        $('[name="date_end"]').on('change',function() {
            var dataEnd = $(this).val();
            setEndDate(((new Date(dataEnd)).getTime())/1000)
          })
    }
      
    async function Submitform() {
        try {
            const body = {
                groupname: groupname,
                deadline_start:startDate,
                deadline_end:endDate,
                test_time: testTime,
                branch: getbranch,
                department: getdepartment,
                position: getposition,
                questionCategories: checkedItems.checked
            };
            console.log(body);
            const response = await axios({
                url: "http://localhost:8000/groups/create", method: "POST", headers: {
                    'Content-Type': "application/json",
                    'Authorization': `Bearer ${localStorage.getItem("token")}`
                }, data: body
            });
            
            //props.history.push('/Категория-вопросов')
        }
        catch (error) {
            
            console.log(error)
        }
    }
  
    // console.log(groupname);
    return (
    <div className="container card pb-4">
        <form onSubmit={Submitform}>
                    <div class="mt-4 mb-4"><h2>Create users group</h2></div>
                    <div class="row">
                        <div class="col-md-4 col-md-offset-4">
                            <label for="formGroupExampleInput">Наименование Группы</label>
                                <input className="groupname form-control" type="text" onChange={(e) => { setgroupname(e.target.value) }} />
                            <br />
                        </div>
                    </div>
                    <div class="row" style={{marginLeft:"10%",marginRight:"10%"}}>
                        <div class="col-md-4">
                            <label for="formGroupExampleInput">Дата начала Тестирование</label>
                            <input className="groupname form-control" name="date_start" type="date" onChange={starthandle} />
                            <br />
                        </div>
                        <div class="col-md-4">
                            <label for="formGroupExampleInput">Дата Окончание Тестирование</label>
                            <input  className="groupname form-control" name="date_end" type="date" onChange={endhandle} />
                            <br />
                        </div>
                        <div class="col-md-4">
                            <label>Enter test_time </label>
                            {/* <input name="date_time" type="text" onChange={timehandle} /> */}
                            <input className="groupnam form-control" type="text" onChange={(e) => { setTestTime(e.target.value) }} />
                            <br />
                        </div>
                    </div>
                    <div class="row" style={{marginLeft:"10%",marginRight:"10%"}}>
                        <div class="col-md-4">
                            <label for="formGroupExampleInput">Branch</label>
                            <select className="form-control" value="choose branch" value={getbranch} onChange={(e) => { setGetBranch(e.target.value) }}>
                                <option value="" defaultValue hidden>Choose Branch</option>
                                {branch.map(item => (
                                    <option key={item.value}
                                        value={item.value}
                                    >
                                        {item.branch}
                                    </option>
                                ))}
                            </select>
                        </div>
                        <div class="col-md-4">
                            <h5>Department</h5>
                            <select className="form-control" value={getdepartment} onChange={(e) => { setGetDepartment(e.target.value) }}>
                                <option value="" defaultValue hidden>Choose Department</option>
                                {department.map(item => (
                                    <option key={item.value}
                                        value={item.value}
                                    >
                                        {item.department}
                                    </option>
                                ))}
                            </select >
                        </div>
                        <div class="col-md-4">
                            <h5>Position</h5>
                            <select className="form-control" defaultValue={getposition} onChange={(e) => { setGetPosition(e.target.value) }}>
                                <option value="" defaultValue hidden>Choose Position</option>
                                {position.map(item => (
                                    <option key={item.value}
                                        value={item.value}
                                    >
                                        {item.position}

                                    </option>
                                ))}
                            </select>
                        </div>
                    </div>
                    <div class="mt-4 mb-4"><h2>Question category</h2></div>
                    <div class={"row mb-4 mt-4"}>
                        <div class="col-md-offset-4 d-flex flex-wrap">
                            
                                    {checkbox.map(item => (
                                        <div style={{lineHeight:"normal"}}>
                                            <span style={{fontSize:"18px",marginRight:"10px",marginLeft:"10px"}}>{item.category}</span>
                                            <label class="switch">
                                                <input className="form-control" type="checkbox"  value={item.category} checked={checkedItems[item.category]} onChange={handleChange} /> 
                                                <span class="slider round"></span>
                                            </label>
                                        </div>
                                    ))}
                        </div>
                    </div>
                    <div class={"row"}>
                        <div class="col-md-4 col-md-offset-4">
                            <input type="button" className="submitform btn btn-primary" value="Save" onClick={Submitform} />
                        </div>
                    </div>
        </form>
        </div>
    )

}
const mapStateToProps = ({isAdmin,router}) => ({isAdmin,router});
export default connect(mapStateToProps)(GroupCreate);