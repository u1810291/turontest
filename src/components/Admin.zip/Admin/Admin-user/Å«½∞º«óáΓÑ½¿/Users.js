import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {connect} from "react-redux";
import UserPagination from './UserPagination';
import UserDetailed from './UsersList';



const Users = (props) => {

    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [usersPerPage, setUsersPerPage] = useState(5);
    useEffect(() => {
        
            setLoading(true);
           axios({url: 'http://localhost:8000/users/all', method:"GET", headers: {
                "Content-Type": "application/json",
                'Authorization': `Bearer ${localStorage.getItem("token")}`
            }}).then(res => {
                console.log(res)
                setUsers(res.data.rows);
                setLoading(false);
            }).catch(e => {
                console.log(e);
            

            });
            
    
}, []);

    // get curent users

    const indexOfLastUser = currentPage * usersPerPage;
    const indexOfFirstUser = indexOfLastUser - usersPerPage;
    const currentUsers = users.slice(indexOfFirstUser, indexOfLastUser);

    // change page

    const paginate = pageNumber => setCurrentPage(pageNumber);
    return (

        <div className='container mt-3 card'>
            <div class="align-selft-center mt-4 mt-4"><h1 style={{color: "dodgerblue"}}>Пользователи</h1></div>
          
            <UserDetailed users={currentUsers} loading={loading}  setUsersPerPage={setUsersPerPage}/>
            <UserPagination usersPerPage={usersPerPage} totalUsers={users.length} paginate={paginate} />
            

        </div>

    );
}

const mapStatetoProps = ({ isAdmin,router}) => ({isAdmin,router});
export default connect(mapStatetoProps)(Users);