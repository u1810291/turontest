import React from 'react'
import $ from 'jquery';
import 'datatables';
import '../../AdminResult.css';
import Loader from "../../../temps/Loader";
window.$ = $;
const UserDetailed = ({ users, loading,edituser,usersPerPage,setUsersPerPage}) => {

    $(document).ready(function() {
        $.fn.dataTable.ext.errMode = 'none';
        $('#example').DataTable({
        
          "ordering": true,
          "paging":false,
          "searching":false,
          "info":false,
          columnDefs: [{
            orderable: false,
            targets: "no-sort"
          }]
      
    
        });
      });


    function handleUsersPerPageChange(e) {
        setUsersPerPage(e.target.value);
        console.log(usersPerPage)
    }

    $(document).ready(function(){
        $("#myInputt").on("keyup", function() {
          var value = $(this).val().toLowerCase();
          $("#myTable tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
          });
        });
      });


    if (loading) {
        return <div className="align-self-test mt-2"><Loader /></div>
    }
    return <div className="container">
        <div className="row mt-4 mb-4">
          <div class="col-md-4 row">
              <div class="col-md-8">
                <input className="form-control" id="myInputt" type="text" placeholder="Search.." />
              </div>
              <div class="col-md-4">
                  <button className="material-button" style={{height: "25px",lineHeight:"25px"}}>Поиск</button>
              </div>
          </div>
          <div className="col-md-2"></div>
          <div className="row col-md-6 text-right">
            <div className="col-md-12">
              <span style={{fontSize: "16px"}}>Кол-во Результатов: </span>
               <select
                      defaultValue={usersPerPage}
                      onChange={handleUsersPerPageChange}
                      style={{width: "80px"}}
                      className="selectt">
                      <option defaultValue="5">5</option>
                      <option value="10">10</option>
                      <option value="15">15</option>
                      <option value="20">20</option>
                  </select>
            </div>
          </div>
        </div>
    <div className="table-responsive table-hover table-bordered">
        <table id="example" className="table-responsive" style={{display:"table"}}>
            <thead className="table-active table-bordered">
            <tr style={{padding:"5px"}}>
                <th>ID:</th>
                <th>Филиал:</th>
                <th>Департамент:</th>
                <th>Должность:</th>
                <th>Фамилия:</th>
                <th>Имя:</th>
                <th>Отчество:</th>
                <th>Логин:</th>
                <th>Активен:</th>
                <th>Группа:</th>
            </tr>
            </thead>
            <tbody id="myTable">
                {users.map(user => (
                    <tr key={user.id} className="table table-bordered" >
                        <td>{user.id}</td>
                        <td>{user.branch}</td>
                        <td>{user.department}</td>
                        <td>{user.position}</td>
                        <td>{user.surname}</td>
                        <td>{user.firstname}</td>
                        <td>{user.lastname}</td>
                        <td>{user.username}</td>
                        <td>{user.isActive}</td>
                        <td>{user.groupName}</td>  
                    </tr>  
                )
                )
                }
            </tbody>
        </table>
        </div>
    </div>
}

export default UserDetailed;

