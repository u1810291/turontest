import React from 'react';
import { Link, Redirect,Route } from "react-router-dom";
import {connect} from "react-redux";

// import Kategoriya from "./Admin-test/Категория-вопросов/Kategoriya";
// import Pagination from "./Admin-user/Пользователи/Pagination";
import Upload from "./Admin-test/Назначение-теста/Upload";
import GroupCreate from "./Admin-user/Группы-пользователи/GroupCreate";
import Editemployee from '../Admin/Admin-test/Категория-группы/Editemployee';
// import Editusers from "../Admin-user/Пользователи/Editusers";
import AdminResult from "../Admin/Result/AdminResult";
import AdminDetailResult from "../Admin/Result/AdminDetailResult";
import Kategoriya from "../Admin/Admin-test/Категория-группы/Kategoriya";
import Users from "../Admin/Admin-user/Пользователи/Users";
import './Admin.css';
import { FAILURE_GET_ADMIN_PERMISSIONS, FAILURE_LOGIN } from '../../store/actions/actionTypes';
import QuestionCategories from './Admin-test/QuestionCategories';

const routes = [
	{
		path: "/Admin/Groups",
		exact: true,
		main: () => <Kategoriya />
    },
    {
		path: "/Admin/Groups/:id",
		exact: true,
		main: () => <Editemployee />
    },
    {
        path: "/Admin/QuestionCategories",
        main: () => <QuestionCategories />
    },
    {
        path: "/Admin/QuestionCategories/:id",
        main: () => <QuestionCategories />
    },
	// {
	// 	path: "/Admin/Пользователи",
	// 	main: () => <Pagination />
	// },
	{
		path: "/Admin/edit/:id",
		main: () => <Editemployee />
	},
	// {
	// 	path: "/Admin/edituser/:id",
	// 	main: () => <Editusers />
	// },
	{
		path: "/Admin/Upload",
		main: () => <Upload />
	},
	{
		path: "/Admin/GroupCreate",
		exact: true,
		main: () => <GroupCreate />
    },
    {
        path: "/Admin/Users/Results",
        exact: true,
        main: () => <AdminResult />
    },
    {
        path: "/Admin/Users/Results/:id",
        exact: true,
        main: () => <AdminDetailResult />
    },
    {
        path: "/Admin/UsersList",
        main: () => <Users />
    },
];


const Admin = (props) => {
    function LogOut(){
        try{
            props.dispatch({type: FAILURE_LOGIN,payload: false});
            localStorage.setItem("token","");
            // props.history.push("/");
            props.history.push("/");
        }catch(e){
            console.log(e);
        }
    }
    if(props.isAdmin.data){
    return (
        <div class="container-fluid" style={{marginBottom:"1%"}}>
                <div class="col-md-12">
                    <nav class="navbar mt-2">
                            <div class="col-md-6">
                                <ul class="nav justify-content-start">
                                    <li class="nav-item navbarItem"><span style={{fontWeight: "bold"}}>{props.isAdmin.data.isAdmin ? "Админ: " : ""}</span></li>
                                    <li class="nav-item navbarItem"><span>{props.isAdmin.data.surname}</span></li>
                                    <li class="nav-item navbarItem"><span>{props.isAdmin.data.firstname}</span></li>
                                    <li class="nav-item navbarItem"><span>{props.isAdmin.data.lastname}</span></li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <ul class="nav justify-content-end">
                                    <li class="nav-item">
                                        <button class="material-button" onClick={()=> props.history.push('/Admin')}>Главная</button>
                                    </li>
                                    <li class="nav-item">
                                        <button class="material-button" href="#">Помощь</button>
                                    </li>
                                    <li class="nav-item">
                                        <button class=" material-button" onClick={LogOut}>Выход</button>
                                    </li>
                                </ul>
                            </div>
                    </nav>
                    
                    <div class="col-md-3 text-left admin-design">
                        <div class="mt-4 col-md-12">
                            <h2>Админ тестов</h2>
                            <hr style={{width: "100%",borderWidth:"1px",borderColor:"#333"}} />
                            <div className={"row"} style={{marginTop: "7px",marginBottom: "7px"}}>
                                <div className={"col-md-12"}>
                                    <button className={"material-button"} onClick={()=> props.history.push('/Admin/QuestionCategories')}>Категория вопросов</button>
                                </div>
                            </div>
                            <div className={"row"} style={{marginTop: "7px",marginBottom: "7px"}}>
                                <div className={"col-md-12"}>
                                    <button className={"material-button"} onClick={()=> props.history.push('/Admin/Groups')}>Группы</button>
                                </div>
                            </div>
                            <div className={"row"} style={{marginTop: "7px",marginBottom: "7px"}}>
                                <div className={"col-md-12"}>
                                    <button className={"material-button"} onClick={()=> props.history.push('/Admin/Upload')}>Загрузить вопросы</button>
                                </div>
                            </div>
                            <div className={"row"} style={{marginTop: "7px",marginBottom: "7px"}}>
                                <div className={"col-md-12"}>
                                    <button className={"material-button"} onClick={()=> props.history.push("/Admin/Users/Results")}>Результаты</button>
                                </div>
                            </div>
                        </div>
                        <div class="mt-4 mb-4 col-md-12">
                            <h2>Админ Пользователей</h2>
                            <hr style={{width: "100%",borderWidth:"1px",borderColor:"#333"}} />
                            <div className={"row"} style={{marginTop: "7px",marginBottom: "7px"}}>
                                <div className={"col-md-12"}>
                                    <button className={"material-button"} onClick={()=> props.history.push('/Admin/UsersList')}>Пользователи</button>
                                </div>
                            </div>
                            <div className={"row"} style={{marginTop: "7px",marginBottom: "7px"}}>
                                <div className={"col-md-12"}>
                                    <button className={"material-button"} onClick={()=> props.history.push('/Admin/GroupCreate')}>Создать группу</button>
                                </div>
                            </div>
                        </div> 
                    </div>
                    <div class="col-md-9 flex-fill">
                        {routes.map((route, index) => (
                            <Route key={index} path={route.path} exact={route.exact} component={route.main} />
                        ))}
                    </div>
            </div>
        </div>
        )
        }else{
            props.dispatch({type: FAILURE_GET_ADMIN_PERMISSIONS,payload: false});
            props.dispatch({type: FAILURE_LOGIN,payload: false});
            localStorage.setItem("token","");
            return (
                <Redirect to={"/"}/>
            )
        }
    
}
const mapStateToProps = ({isAdmin,router}) => ({isAdmin,router});
export default connect(mapStateToProps)(Admin);