import React from 'react'

const KategoriyaPagination = ({ usersPerPage, totalUsers, paginate }) => {
    const pageNumbers = [];

    for (let i = 1; i <= Math.ceil(totalUsers / usersPerPage); i++) {
        pageNumbers.push(i);
    }

    return (
        <div>
            <nav>
                <ul className='pagination nav justify-content-center m-4' >
                    {pageNumbers.map(number => (
                        <li key={number} className='nav-item'>
                            <a onClick={() => paginate(number)} href='#' className='page-link mr-2 ml-2'>
                                {number}
                            </a>
                        </li>
                    ))}
                </ul>
            </nav>
        </div>
    )
}

export default KategoriyaPagination;