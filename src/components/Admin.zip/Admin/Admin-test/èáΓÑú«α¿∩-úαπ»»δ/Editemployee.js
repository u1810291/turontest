import React, { useState, useEffect } from 'react'
import {connect} from 'react-redux';
import {withRouter} from "react-router-dom";
import axios from 'axios';
import './Editemployee.css';
const Editemployee = (props) => {
  
    const [employee, setEmployee] = useState({ id:'', groupname: '', branch: '', department: '', position: '', questionCategoryId1: '', questionCategoryId2: '', questionCategoryId3: '', });
    const id = props.match.params.id;

    async function GetData() {
        try {
            const res = await axios({
                url: `http://localhost:8000/group/${id}`,
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    'Authorization': `Bearer ${localStorage.getItem("token")}`
                }
            });
            const body = await (res.data);
            setEmployee(body);
            console.log(res.data);
        }
        catch (error) {
            console.log(error);
        }
    }

    useEffect(() => {
        // if(employee.groupname === undefined || employee.groupname === null){
            GetData();
        //}
    }, []);


    const UpdateEmployee = (e) => {
        e.preventDefault();
        try{
            const data = { id: props.match.params.id, groupname: employee.groupname, branch: employee.branch, department: employee.department, position: employee.position };
            axios({
                url: `http://localhost:8000/group/edit/${id}`, method: "PATCH", headers: {
                    'Content-Type': "application/json",
                    'Authorization': `Bearer ${localStorage.getItem("token")}`
                },data:data});
                console.log(data);
            //props.history.push('/Категория-вопросов/');
        }catch(error){
            console.log(error)
        }
       
    };

    const onChange = (e) => {
        e.persist();
        setEmployee({ ...employee, [e.target.name]: e.target.value });
    }

    return (
        <div className="card">
           
            <form onSubmit={UpdateEmployee}>
                <div class="align-selft-center mt-4 mb-4">
                    <h1 style={{color: "dodgerblue"}}>Изменение Группы</h1>
                </div>        
                <div className="Inputt container">
                    <div class="row">
                        <div className="col-md-1"></div>
                        <div className="mt-5 mb-5 inputdes col-md-5">
                            <div className="pt-3 col-md-5">
                                <span>ID:</span>
                            </div>
                            <div className="col-md-7">
                                <input type="text" className="form-control" name="id" id="id" placeholder="id" value={employee.id} onChange={onChange} />
                            </div>
                        </div>    
                        <div className="mt-5 mb-5 inputdes col-md-5">
                            <div className="col-md-5">
                                <span>Наименование группы:</span>
                            </div>
                            <div className="col-md-7">
                                <input type="text" className="form-control" name="groupname" id="groupname" placeholder="Наименование группы" value={employee.groupname} onChange={onChange} />
                            </div>
                        </div>
                        <div className="col-md-1"></div>
                    </div>
                    <div className="container Inputt">
                        <div class="row">
                            <div className="col-md-1"></div>
                            <div className="mb-5 inputdes col-md-5">
                                <div className="pt-3 col-md-5">
                                    <span>Департамент:</span>
                                </div>
                                <div className="col-md-7">
                                    <input type="text" className="form-control" name="department" id="department" placeholder="Департамент" value={employee.department} onChange={onChange} />
                                </div>
                            </div>    
                            <div className="mb-5 inputdes col-md-5">
                                <div className="pt-3 col-md-5">
                                    <span>Филиал:</span>
                                </div>
                                <div className="col-md-7">
                                    <input type="text" className="form-control" name="branch" id="branch" placeholder="Филиал" value={employee.branch} onChange={onChange} />
                                </div>
                            </div>
                            <div className="col-md-1"></div>
                        </div>
                    </div>
                    <div className="mb-5 container Inputt">
                        <div class="row">
                            <div className="col-md-1"></div>
                            <div className="inputdes col-md-5">
                                <div className="pt-3 col-md-5">
                                    <span>Должность:</span>
                                </div>
                                <div className="col-md-7">
                                    <input type="text" className="form-control" name="position" id="position" placeholder="Должность" value={employee.position} onChange={onChange} />
                                </div>
                            </div>    
                            
                            <div className="col-md-1"></div>
                        </div>
                    </div>
                    
                    {/* <div className="inputdes">
                <p>questioncategory1</p>
                    <input type="text" placeholder="questioncategory1" name="questioncategory1" id="questioncategory1" value={employee.questionCategoryId1} onChange={onChange} />
                </div>
            
                <div className="inputdes">
                <p>questioncategory2</p>
                    <input type="text" placeholder="questioncategory2" name="questioncategory2" id="questioncategory1" value={employee.questionCategoryId2} onChange={onChange} />
                </div>
               
                <div className="inputdes">
                <p>questioncategory3</p>
                    <input type="text" placeholder="questioncategory3" name="questioncategory3" id="questioncategory1" value={employee.questionCategoryId3} onChange={onChange} />
                </div> */}
                    <div className="row mt-2 mb-2">
                        <div class="col-md-4"></div>
                        <div className="col-md-4">
                            <div className="col-md-6 row mb-4">
                                <button type="submit" className="material-button" style={{width: "100%"}}><span>Сохранить</span></button>
                            </div>
                            <div className="col-md-6 row mb-4">
                                <button className="material-button" style={{width: "100%"}}><span>Отмена</span></button>
                            </div>
                        </div>
                        <div class="col-md-4"></div>
                    </div>  
                </div>
            </form>
        </div>
    )
}
const mapStateToProps = ({isAdmin,router}) => ({isAdmin,router});
export default connect(mapStateToProps)(withRouter(Editemployee));