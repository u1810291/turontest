import React from 'react'
import './Kategoriya.css'
import 'datatables';
import $ from 'jquery';
window.$ = $;
const KategoriyaUsers = ({ users, loading,editemployee,usersPerPage,setUsersPerPage }) => {

    $(document).ready(function() {
        $.fn.dataTable.ext.errMode = 'none';
        $('#example').DataTable({
          "ordering": true,
          "paging":false,
          "searching":false,
          "info":false,
          columnDefs: [{
            orderable: false,
            targets: "no-sort"
          }]
      
    
        });
      });

    function handleUsersPerPageChange(e) {
        setUsersPerPage(e.target.value);
        console.log(usersPerPage)
    }

    $(document).ready(function(){
        $("#myInput").on("keyup", function() {
          var value = $(this).val().toLowerCase();
          $("#myTable tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
          });
        });
      });

    if (loading) {
        return <h2>Loading...</h2>  //Add loader
    }
    return <div className="container">
        <div className="row mt-4 mb-4">
          
          <div class="col-md-4 row">
            <div class="col-md-8">
              <input className="form-control searchForm" id="myInput" type="text" placeholder="Search.." />
            </div>
            <div class="col-md-4">
                <button className="material-button" style={{height: "25px",lineHeight:"25px"}}>Поиск</button>
            </div>
            
          </div>
          <div className="col-md-2"></div>
         {/* <div className="col-md-6 selectresult-pagination"> */}
            <div className="row col-md-6 text-right">
              <div className="col-md-12">
                <span style={{fontSize: "16px"}}>Кол-во Результатов: </span>
                <select 
                  defaultValue={usersPerPage}
                  onChange={handleUsersPerPageChange}
                  style={{width: "80px"}}
                  >
                  <option className="form-control" defaultValue="5">5</option>
                  <option className="form-control" value="10">10</option>
                  <option className="form-control" value="15">15</option>
                  <option className="form-control" value="20">20</option>
                    
                    </select>
              </div>
              
            </div>
          {/* </div> */}
        </div>
        <div className="table-responsive table-bordered table-hover">
        <table  id="example" className="table" style={{display: "table"}}>
            <thead  className="table-active">        
            <tr>
                <th>№</th>
                <th>GroupName</th>
                <th>Deadline_start</th>
                <th>Deadline_end</th>
                <th>Branch</th>
                <th>Department</th>
                <th>Position</th>
                <th>AssignQuestion1</th>
                <th>AssignQuestion2</th>
                <th>AssignQuestion3</th>
                <th>Action</th>
            </tr>
            </thead> 
            <tbody id="myTable table table-responsive">
                {users.map((user,i) => (
                    <tr key={user.id} className="table table-bordered">
                        <td>{i+1}</td>
                        <td>{user.groupname}</td>
                        <td>{user.deadline_start}</td>
                        <td>{user.deadline_end}</td>
                        <td>{user.branch}</td>
                        <td>{user.department}</td>
                        <td>{user.position}</td>
                        <td>{user.questionCat1}</td>
                        <td>{user.questionCat2}</td>
                        <td>{user.questionCat3}</td> 
                        <td>  
                          <div className="btn-group">  
                            <button className="material-button" style={{height: "25px",lineHeight:"25px",margin:"5px"}} onClick={() => { editemployee(user.id) }}>Edit</button>  
                          </div>  
                        </td>   
                    </tr>
                )
                )
                }
           
            </tbody>
        </table>
        </div>
    </div>
}

export default KategoriyaUsers;




