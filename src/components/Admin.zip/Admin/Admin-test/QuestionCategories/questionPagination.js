import React from 'react'

const QuestionPagination = ({ questionsPerPage, totalQuestions, paginate }) => {
    const pageNumbers = [];

    for (let i = 1; i <= Math.ceil(totalQuestions / questionsPerPage); i++) {
        pageNumbers.push(i);
    }

    return (
        <div>
            <nav>
                <ul className='pagination nav justify-content-center m-4' >
                    {pageNumbers.map(number => (
                        <li key={number} className='nav-item'>
                            <a onClick={() => paginate(number)} href='#' className='page-link mr-2 ml-2'>
                                {number}
                            </a>
                        </li>
                    ))}
                </ul>
            </nav>
        </div>
    )
}

export default QuestionPagination;