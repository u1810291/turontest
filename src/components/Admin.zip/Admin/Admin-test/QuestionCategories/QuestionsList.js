import React from 'react'
import "./questionCategories.css";
import 'datatables';
import $ from 'jquery';
import Loader from "../../../temps/Loader";
window.$ = $;
const QuestionsList = ({ questions, loading,editQuestions,questionsPerPage,setQuestionsPerPage }) => {

    $(document).ready(function() {
        $.fn.dataTable.ext.errMode = 'none';
        $('#example').DataTable({
          "ordering": true,
          "paging":false,
          "searching":false,
          "info":false,
          columnDefs: [{
            orderable: false,
            targets: "no-sort"
          }]
      
    
        });
      });

    function handleUsersPerPageChange(e) {
        setQuestionsPerPage(e.target.value);
        console.log(questionsPerPage)
    }

    $(document).ready(function(){
        $("#myInput").on("keyup", function() {
          var value = $(this).val().toLowerCase();
          $("#myTable tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
          });
        });
      });

    if (loading) {
        return <div className="align-self-center mt-4 mb-4"><Loader /> </div> //Add loader
    }
    return <div className="container">
        <div className="row mt-4 mb-4">
          
          <div class="col-md-4 row">
            <div class="col-md-8">
              <input className="form-control searchForm" id="myInput" type="text" placeholder="Search.." />
            </div>
            <div class="col-md-4">
                <button className="material-button" style={{height: "25px",lineHeight:"25px"}}>Поиск</button>
            </div>
            
          </div>
          <div className="col-md-2"></div>
         {/* <div className="col-md-6 selectresult-pagination"> */}
            <div className="row col-md-6 text-right">
              <div className="col-md-12">
                <span style={{fontSize: "16px"}}>Кол-во Результатов: </span>
                <select 
                  defaultValue={questionsPerPage}
                  onChange={handleUsersPerPageChange}
                  style={{width: "80px"}}
                  >
                  <option className="form-control" defaultValue="5">5</option>
                  <option className="form-control" value="10">10</option>
                  <option className="form-control" value="15">15</option>
                  <option className="form-control" value="20">20</option>
                    
                    </select>
              </div>
              
            </div>
          {/* </div> */}
        </div>
        <div className="table-responsive table-bordered table-hover">
        <table  id="example" className="table" style={{display: "table"}}> 
            <tbody id="myTable table table-responsive">
                {/* {questions.map((question,i) => (
                    <tr key={question.id} className="table table-bordered">
                        <td>{i+1}</td>
                        <td>{question.groupname}</td>
                        <td>{question.deadline_start}</td>
                        <td>{question.deadline_end}</td>
                        <td>{question.branch}</td>
                        <td>{question.department}</td>
                        <td>{question.position}</td>
                        <td>{question.questionCat1}</td>
                        <td>{question.questionCat2}</td>
                        <td>{question.questionCat3}</td> 
                        <td>  
                          <div className="btn-group">  
                            <button className="material-button" style={{height: "25px",lineHeight:"25px",margin:"5px"}} onClick={() => { editQuestions(question.id) }}>Edit</button>  
                          </div>  
                        </td>   
                    </tr>
                )
                )
                } */}
                
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Категория</th>
                      <th>Время</th>
                    </tr>
                  </thead>
                  {
                  questions.map((data)=>{
                  return <tr>
                    <td>{data.id}</td>
                    <td>{data.category}</td>
                    <td>{data.time}</td>
                  </tr>
                  })
                  }
            </tbody>
        </table>
        </div>
    </div>
}

export default QuestionsList;