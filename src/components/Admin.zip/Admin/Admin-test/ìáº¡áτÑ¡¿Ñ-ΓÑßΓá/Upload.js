import React, { useState } from 'react';
import axios from 'axios';

import QuestionUpload from "../../../temps/QuestionUpload/index";
import './Upload.css';

const  Upload = (props) => {
    return (
        <div className="App">
            {/* <div className="uploadform">
            <h3>Import Questions</h3>
            </div>
                <label > 
                     Name
                <input className="Name" type="text" value={title}
                        onChange={(e) => { setTitle(e.target.value) }}
                        placeholder="Give a title to your upload" />
                </label>

                <label>
                    File
                    <input className="File" type="file"  onChange={(e) => setFile(e.target.files[0])} />
                </label>

                <input className="Upload" type="button" value="Submit" onClick={uploadWithFormData} /> */}
                <QuestionUpload />
        </div>
    );
}

export default Upload;