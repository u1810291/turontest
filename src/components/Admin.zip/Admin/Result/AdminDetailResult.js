
import React, { useState, useEffect } from 'react';
import {connect} from "react-redux";
import {withRouter} from 'react-router-dom';
import axios from 'axios';

const AdminDetailResult = (props) => {
    const [detailuser, setDetailuser] = useState([]);
    const [detailuser2, setDetailuser2] = useState([]);
    const [detailuser3, setDetailuser3] = useState([]);
    const [passed, setPassed] = useState("");
    const additional = props.match.params.id;
    const [resultId, setIDD] = (additional);

    async function GetDataUsers() {
        try {
            console.log("HEY!");
            const res = await axios({

                url: `http://localhost:8000/results/byResultId/${resultId}`,
                method: 'get',
                headers: {
                    "Content-Type": "application/json",
                    'Authorization': `Bearer ${localStorage.getItem("token")}`
                }
            }).then((res)=>{
                if(res.data.rows === undefined || res.data.rows === null){
                    setDetailuser([]);
                    setDetailuser2([]);
                    setDetailuser3([]);
                    console.log(res.data);
                }else{
                    setDetailuser(res.data.rows.user);
                    setDetailuser2(res.data.rows);
                    setDetailuser3(res.data.rows.questionCategory);
                    if (res.data.rows.passed === 1) {
                        setPassed("passed");
                        // console.log('passed');
                    }
                    if (res.data.rows.passed === 0) {
                        setPassed("failed")

                    }
                    console.log(res.data);
                }
            });
            

        }
        catch (error) {
            console.log(error);
        }

    }
    useEffect(() => {
        //if(detailuser.length <= 0 || detailuser === undefined || detailuser === null){
            GetDataUsers();
        //}
    }, []);


    return (
        <div class="Container">
            <div class="Card">
                <legend style={{textAlign:"center",fontWeight:"bold",marginBottom:"20px"}}>Персональные данные</legend>
                <div class="row text-left mt-3 userInfoDiv">
                    <div class="col-md-2"></div>
                    <div class="col-md-4 p-2"><h4>Фамилия:</h4></div>
                    <div class="col-md-4 userDetails p-2 rounded-lg"><h4>{detailuser.surname}</h4></div>
                    <div class="col-md-2 "></div>
                </div>
                <div class="row text-left mt-3 userInfoDiv">
                    <div class="col-md-2"></div>
                    <div class="col-md-4 p-2"><h4>Имя:</h4></div>
                    <div class="col-md-4 userDetails p-2 rounded-lg"><h4>{detailuser.firstname}</h4></div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row text-left mt-3 userInfoDiv">
                    <div class="col-md-2"></div>
                    <div class="col-md-4 p-2"><h4>Отчество:</h4></div>
                    <div class="col-md-4 userDetails p-2 rounded-lg"><h4>{detailuser.lastname}</h4></div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row text-left mt-3 userInfoDiv">
                    <div class="col-md-2"></div>
                    <div class="col-md-4 p-2"><h4>Филиал:</h4></div>
                    <div class="col-md-4 userDetails p-2 rounded-lg"><h4>{detailuser.branch}</h4></div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row text-left mt-3 userInfoDiv">
                    <div class="col-md-2"></div>
                    <div class="col-md-4 p-2"><h4>Департамент:</h4></div>
                    <div class="col-md-4 userDetails p-2 rounded-lg"><h4>{detailuser.department}</h4></div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row text-left mt-3 userInfoDiv">
                    <div class="col-md-2"></div>
                    <div class="col-md-4 p-2"><h4>Должность:</h4></div>
                    <div class="col-md-4 userDetails p-2 rounded-lg"><h4>{detailuser.position}</h4></div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row text-left mt-3 userInfoDiv">
                    <div class="col-md-2"></div>
                    <div class="col-md-4 p-2"><h4>Категория вопросов:</h4></div>
                    <div class="col-md-4 userDetails p-2 rounded-lg"><h4>{detailuser3.category}</h4></div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row text-left mt-3 userInfoDiv">
                    <div class="col-md-2"></div>
                    <div class="col-md-4 p-2"><h4>Количество вопросов:</h4></div>
                    <div class="col-md-4 userDetails p-2 rounded-lg"><h4>{detailuser2.total_questions}</h4></div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row text-left mt-3 userInfoDiv">
                    <div class="col-md-2"></div>
                    <div class="col-md-4 p-2"><h4>Время на тест:</h4></div>
                    <div class="col-md-4 userDetails p-2 rounded-lg"><h4>{detailuser3.time}</h4></div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row text-left mt-3 userInfoDiv">
                    <div class="col-md-2"></div>
                    <div class="col-md-4 p-2"><h4>Время начала теста:</h4></div>
                    <div class="col-md-4 userDetails p-2 rounded-lg"><h4>{detailuser2.start_time}</h4></div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row text-left mt-3 userInfoDiv">
                    <div class="col-md-2"></div>
                    <div class="col-md-4 p-2"><h4>Время окончания теста:</h4></div>
                    <div class="col-md-4 userDetails p-2 rounded-lg"><h4>{detailuser2.end_time}</h4></div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row text-left mt-3 userInfoDiv">
                    <div class="col-md-2"></div>
                    <div class="col-md-4 p-2"><h4>Правильных ответов:</h4></div>
                    <div class="col-md-4 userDetails p-2 rounded-lg"><h4>{detailuser2.correct_answers}</h4></div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row text-left mt-3 userInfoDiv">
                    <div class="col-md-2"></div>
                    <div class="col-md-4 p-2"><h4>Неправильных ответов:</h4></div>
                    <div class="col-md-4 userDetails p-2 rounded-lg"><h4>{detailuser2.wrong_answers}</h4></div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row text-left mt-3 userInfoDiv">
                    <div class="col-md-2"></div>
                    <div class="col-md-4 p-2"><h4>Балл:</h4></div>
                    <div class="col-md-4 userDetails p-2 rounded-lg"><h4>{detailuser2.score}</h4></div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row text-left mt-3 userInfoDiv">
                    <div class="col-md-2"></div>
                    <div class="col-md-4 p-2"><h4>Комментарий:</h4></div>
                    <div class="col-md-4 userDetails p-2 rounded-lg"><h4>{detailuser2.comment}</h4></div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row text-left mt-3 userInfoDiv">
                    <div class="col-md-2"></div>
                    <div class="col-md-4 p-2"><h4>Попыток:</h4></div>
                    <div class="col-md-4 userDetails p-2 rounded-lg"><h4>{detailuser2.attempted}</h4></div>
                    <div class="col-md-2"></div>
                </div>
                <div class="row text-left mt-3 userInfoDiv">
                    <div class="col-md-2"></div>
                    <div class="col-md-4 p-2"><h4>Успешно пройден:</h4></div>
                    <div class="col-md-4 userDetails p-2 rounded-lg"><h4>{detailuser2.passed ? "Да" : "Нет"}</h4></div>
                    <div class="col-md-2"></div>
                </div>
            </div>
        </div>
    )

}

const mapStateToProps = ({router,isAdmin}) => ({router,isAdmin});
export default connect(mapStateToProps)(withRouter(AdminDetailResult));