import React from 'react';
import {connect} from "react-redux";
import './AdminResult.css';
import 'datatables';
import $ from 'jquery';

import Loader from "../../temps/Loader";

window.$ = $;

 const AdminResultUsers = ({adminresults, detailemployee,loading,usersPerPage,setUsersPerPage}) => {
   
    $(document).ready(function() {
        $.fn.dataTable.ext.errMode = 'none';
        $('#example').DataTable({
        
          "ordering": true,
          "paging":false,
          "searching":false,
          "info":false,
          columnDefs: [{
            orderable: false,
            targets: "no-sort"
          }]
      
    
        });
      });
   
    function handleUsersPerPageChange(e) {
        setUsersPerPage(e.target.value);
        console.log(usersPerPage)
    }

    $(document).ready(function(){
        $("#myInput").on("keyup", function() {
          var value = $(this).val().toLowerCase();
          $("#myTable tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
          });
        });
      });

     
    
    return loading ? (
      <div className="align-self-center"><Loader /></div>
      ) : (
         <div className="container">
          <div className="row mt-4 mb-4">
            
            <div class="col-md-4 row">
              <div class="col-md-8">
                <input className="form-control searchForm" id="myInput" type="text" placeholder="Search.." />
              </div>
              <div class="col-md-4">
                  <button className="material-button" style={{height: "20px",lineHeight:"20px"}}>Поиск</button>
              </div>
              
            </div>
            <div className="col-md-2"></div>
          {/* <div className="col-md-6 selectresult-pagination"> */}
              <div className="row col-md-6 text-right">
                <div className="col-md-12">
                  <span style={{fontSize: "16px"}}>Кол-во Результатов: </span>
                  <select 
                    defaultValue={usersPerPage}
                    onChange={handleUsersPerPageChange}
                    style={{width: "80px"}}
                    >
                    <option className="form-control" defaultValue="5">5</option>
                    <option className="form-control" value="10">10</option>
                    <option className="form-control" value="15">15</option>
                    <option className="form-control" value="20">20</option>
                      
                      </select>
                </div>
                
              </div>
            {/* </div> */}
          </div>
         <div className="table-responsive table-hover table-bordered">
        
          <table id="example" className="table-responsive" style={{display:"table"}}>
            
              <thead className="table-active">
              <tr >
                  <th >№</th>
                  <th >Фамилия</th>
                  <th >Имя</th>
                  <th >Отчество</th>
                  <th >Филиал</th>
                  <th >Департамент</th>
                  <th >Должность</th>
                  <th >Категория</th>
                  <th >Дата</th>
                  <th >Пройден</th>
                  <th >Действие</th>
              </tr>
              </thead>
              <tbody id="myTable">
              {adminresults.map((adminresult,i)=>(
                  <tr key={adminresult.id}  className=""
                  >
                    <td>{i+1}</td>
                    
                    <td >{adminresult.user.surname}</td>
                    <td>{adminresult.user.firstname}</td>
                    <td >{adminresult.user.lastname}</td>
                    <td >{adminresult.user.branch}</td>
                    <td>{adminresult.user.department}</td>
                    <td >{adminresult.user.position}</td>
                    <td >{adminresult.questionCategory.category}</td>
                    <td >{adminresult.end_time}</td>
                    <td >{adminresult.passed === 1 ? (adminresult.passed='Да')
                    :( adminresult.passed='Нет' )}</td>
                    <td>  
                    <div>  
                      <button className="material-button" style={{height: "20px",lineHeight:"20px",margin:"10px"}} onClick={() => {detailemployee(adminresult.id) }}>Info</button>  
                    </div> 
                    </td>
                </tr>
            
              ))}

              </tbody>
          </table>
        
      </div>
    
  
      </div>
    
    )
}
const mapStateToProps = ({router,isAdmin}) => ({router,isAdmin});
export default connect(mapStateToProps)(AdminResultUsers);