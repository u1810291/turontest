import React from 'react'
import {connect} from "react-redux";
const AdminResultPagination = ({ usersPerPage, totalUsers, paginate }) => {
    const pageNumbers = [];

    for (let i = 1; i <= Math.ceil(totalUsers / usersPerPage); i++) {
        pageNumbers.push(i);
    }

    return (
        <div>
            <nav>
                <ul className='pagination nav justify-content-center m-4'>
                    {pageNumbers.map(number => (
                        <li key={number} className='nav-item'>
                            <a onClick={() => paginate(number)} href='#' className='page-link mr-2 ml-2'>
                                {number}
                            </a>
                        </li>
                    ))}
                </ul>
            </nav>
        </div>
    )
}

const mapStateToProps = ({router,isAdmin}) => ({router,isAdmin});
export default connect(mapStateToProps)(AdminResultPagination);