import React,{useState,useEffect} from 'react'
import {connect} from 'react-redux';
import {withRouter} from 'react-router-dom';
import axios from 'axios';


import AdminResultPagination from './AdminResultPagination';
import AdminResultUsers from './AdminResultUsers';
import './AdminResult.css';

function AdminResult(props){
     const [loading,setLoading]=useState(false);
     const [adminresults,setAdminresults]=useState([]);
     const [currentPage, setCurrentPage] = useState(1);
     const [usersPerPage, setUsersPerPage] = useState(5);
     function detailemployee(id){
        //console.log(props);
        props.history.push(`/Admin/Users/Results/${id}`);
    }

     useEffect(() => {
        setLoading(true);
       axios({url: 'http://localhost:8000/results/all', method:"GET", headers: {
            "Content-Type": "application/json",
            'Authorization': `Bearer ${localStorage.getItem("token")}`
        }}).then(res => {
           
            setAdminresults(res.data.rows);
            console.log(res.data.rows);
            setLoading(false);
           
        }).catch(e => {
            console.log(e);
       
        });
}, []);





const indexOfLastUser = currentPage * usersPerPage;
const indexOfFirstUser = indexOfLastUser - usersPerPage;
const currentUsers = adminresults.slice(indexOfFirstUser, indexOfLastUser);

// change page


const paginate = pageNumber => setCurrentPage(pageNumber);
return (
    <div className="container card">
      <div> <h1 style={{color: "dodgerblue"}}>Результаты</h1> </div>
        <AdminResultUsers adminresults={currentUsers} loading={loading} detailemployee={detailemployee} setUsersPerPage={setUsersPerPage} />
        <AdminResultPagination usersPerPage={usersPerPage} totalUsers={adminresults.length} paginate={paginate} /> 
    </div>

);
}
const mapStateToProps = ({router,isAdmin}) => ({router,isAdmin});
export default connect(mapStateToProps)(withRouter(AdminResult));
